
# https://docs.python.org/2/library/xml.etree.elementtree.html

import xml.etree.ElementTree as ET 
tree = ET.parse('icdClaML2016ens.xml')
root = tree.getroot()

print('icd_code|description')
for c in root.iter('Class'):
	code = c.get('code')
	desc = c.find('Rubric').find('Label').text
	print(code,'|',desc,sep='')

