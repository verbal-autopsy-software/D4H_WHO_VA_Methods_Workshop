.mode column
.header on
.echo on

.open va_icd_codes.db

drop table if exists va_codes;
.import ICD10_codes_kisesa_agincourt.csv va_codes

drop table if exists icd_codes;
.separator "|"
.import icd10_codes.txt icd_codes

.tables

-- select * from va_codes;
-- select * from icd_codes;

.headers on
.mode csv

-- OUTPUT ALL VA CODES, VALID OR NOT
.output va_icd_codes.csv
select
	* 
from
	va_codes v 
		left join icd_codes c 
		on trim(v.va_icd_code) = trim(c.icd_code);


-- OUTPUT VALID VA CODES
.output va_icd_codes_VALID.csv
select
	* 
from
	va_codes v 
		left join icd_codes c 
		on trim(v.va_icd_code) = trim(c.icd_code)
where
	c.icd_code is not null;
